# Web-Slot-SweetNeon
 Web simple Slot using PHP and JavaScript.

CHARACTERISTICS:

- Three-tier betting system.
- Roller retainer system.
- UX and sound feedback.


# User Interface Images

## Screenshot of slot without action

![Screenshot of slot without action.](https://github.com/EnriqueSanVic/Web-Slot-SweetNeon/blob/main/screenshots/slot1.PNG?style=centerme)

## Screenshot of slot with roller retainer

![Screenshot of slot with roller retainer.](https://github.com/EnriqueSanVic/Web-Slot-SweetNeon/blob/main/screenshots/slot2.PNG?style=centerme)

## Screenshot of slot with action of prize

![Screenshot of slot with action of prize.](https://github.com/EnriqueSanVic/Web-Slot-SweetNeon/blob/main/screenshots/slot3.PNG?style=centerme)
